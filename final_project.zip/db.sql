-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.29-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for rent
CREATE DATABASE IF NOT EXISTS `rent` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `rent`;


-- Dumping structure for table rent.admins
CREATE TABLE IF NOT EXISTS `admins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table rent.admins: ~1 rows (approximately)
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, 'admin', 'mshafnaz12225@gmail.com', NULL, '$2y$10$8h2yBIwQOOQer6aruIOlhuJlgNRpeF.eQPYCrGfj0BdImJu9jVCXG', 'bLze72rGIDDbTUZUWyYCxujjWt1WcisG7s9kzKhPZyt5qfTgcBgukoaKX6Zr', '2020-04-04 05:56:42', '2020-06-05 13:50:14');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;


-- Dumping structure for table rent.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table rent.migrations: ~11 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(4, '2020_02_16_113016_create_logs_table', 2),
	(5, '2020_02_16_122152_create_logs_table', 3),
	(25, '2014_10_12_000000_create_users_table', 4),
	(26, '2014_10_12_100000_create_password_resets_table', 4),
	(27, '2020_02_16_080122_create_vehicles_table', 4),
	(28, '2020_02_16_134426_create_admins_table', 4),
	(29, '2020_03_18_065727_add_user_id_to_vehicles', 4),
	(30, '2020_03_19_055112_create_vehicle_pictures_table', 4),
	(31, '2020_04_07_045248_create_reservations_table', 5),
	(32, '2020_04_09_084718_create_reservations_table', 6),
	(33, '2020_04_10_134656_create_reservations_table', 7),
	(34, '2020_06_04_162728_add_mileage_to_vehicles', 8);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;


-- Dumping structure for table rent.password_resets
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table rent.password_resets: ~1 rows (approximately)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
	('test@test.com', '$2y$10$.ZD6ZCpopw150XuTVRt7b.WSY05q7MjdZWZ/w0e7t9OfobJ3kCPtu', '2020-04-22 07:35:58');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;


-- Dumping structure for table rent.reservations
CREATE TABLE IF NOT EXISTS `reservations` (
  `res_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lic_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lic_expiry` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pick_date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `return_date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rent_amount` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`res_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table rent.reservations: ~3 rows (approximately)
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
INSERT INTO `reservations` (`res_id`, `name`, `lic_no`, `lic_expiry`, `phone`, `address`, `pick_date`, `return_date`, `rent_amount`, `status`, `vid`, `user_id`, `created_at`, `updated_at`) VALUES
	(2, 'mohamed', 'B456478', '2021-02-15', '0771234567', '156/A, Main Road, Akurana', '2020-04-10', '2020-04-13', '19500', 'pending', 24, 4, '2020-04-10 13:58:42', '2020-04-10 13:58:42'),
	(3, 'mohamed', 'B456478', '2021-02-15', '0771234567', '156/A, Main Road, Akurana', '2020-04-15', '2020-04-16', '8000', 'confirmed', 29, 4, '2020-04-11 15:06:27', '2020-04-14 08:33:02'),
	(4, 'shafnas', 'B234567', '2023-06-15', '0770048000', '286, Main Road, Akurana', '2020-04-10', '2020-04-13', '24000', 'pending', 29, 3, '2020-04-11 15:47:29', '2020-04-11 16:09:22'),
	(7, 'shafnas', 'B234567', '2020-09-18', '0770048000', '192/1, dodangolla', '2020-06-22', '2020-06-24', '13000', 'pending', 24, 3, '2020-06-05 06:28:56', '2020-06-05 06:28:56');
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;


-- Dumping structure for table rent.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table rent.users: ~4 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `phone`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `user_type`) VALUES
	(1, 'iRent', 'test@test.com', '0774295787', NULL, '$2y$10$qIfw1y2VHbQvMkQoU2aRIeZB9gENys4HdVJJDzqgH1/q2jJbi1D4m', NULL, '2020-03-19 09:08:49', '2020-04-07 15:03:13', 'seller'),
	(2, 'Rdx Rent', 'rdxrent@gmail.com', '0772478345', NULL, '$2y$10$1HAY86/ECjBPym1DoGhM6uUxJBl7bhJFsOvqfIjdCF3wYyC5/KW8e', NULL, '2020-03-22 13:32:19', '2020-03-22 13:32:19', 'seller'),
	(3, 'shafnas', 'mshafnaz@hotmail.com', '0770048000', NULL, '$2y$10$c71Ij8LP29RfybjCNg41XewbMj3LBpnf8vZOappK9N5oqJ2P2kCOC', 'io4bqccUqSIdtfIbr5f9oVVYxb7tPc5jUwmMcmxuMGusQf01ED4Q2oDacN1L', '2020-04-06 08:04:40', '2020-06-01 14:22:08', 'user'),
	(4, 'mohamed', 'mohamed@gmail.com', '0771234567', NULL, '$2y$10$dptgCN6rT4EBvm7jrdRpMuxgTf29NiuS3R9x5Rxoo5y0IaR9x2eK6', NULL, '2020-04-10 13:56:25', '2020-04-10 13:56:25', 'user');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;


-- Dumping structure for table rent.vehicles
CREATE TABLE IF NOT EXISTS `vehicles` (
  `vid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `make` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transmission` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fuel` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type_of_drive` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `mileage` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`vid`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table rent.vehicles: ~3 rows (approximately)
/*!40000 ALTER TABLE `vehicles` DISABLE KEYS */;
INSERT INTO `vehicles` (`vid`, `title`, `type`, `make`, `model`, `transmission`, `fuel`, `type_of_drive`, `price`, `mileage`, `district`, `city`, `created_at`, `updated_at`, `user_id`) VALUES
	(24, 'Suzuki Wagon R FZ', 'car', 'suzuki', 'Wagon R FZ', 'automatic', 'hybrid', 'self', 6500, '300', 'kandy', 'Akurana', '2020-03-22 15:58:02', '2020-03-22 15:58:02', 2),
	(27, 'Toyota Prius', 'car', 'toyota', 'Prius XW30', 'automatic', 'hybrid', 'driver', 7500, '300', 'kandy', 'Akurana', '2020-03-24 14:31:53', '2020-06-05 04:54:50', 1),
	(29, 'Toyota KDH 201', 'van', 'toyota', 'KDH', 'automatic', 'diesel', 'self', 8000, '300', 'kandy', 'Akurana', '2020-04-05 08:16:21', '2020-04-05 08:16:21', 1);
/*!40000 ALTER TABLE `vehicles` ENABLE KEYS */;


-- Dumping structure for table rent.vehicle_pictures
CREATE TABLE IF NOT EXISTS `vehicle_pictures` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cover_image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vid` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table rent.vehicle_pictures: ~6 rows (approximately)
/*!40000 ALTER TABLE `vehicle_pictures` DISABLE KEYS */;
INSERT INTO `vehicle_pictures` (`id`, `cover_image`, `vid`, `created_at`, `updated_at`) VALUES
	(11, 'wagon_24_jpg', 24, '2020-03-22 15:58:04', '2020-03-22 15:58:04'),
	(15, 'wagon_2_24_jpg', 24, '2020-03-22 15:58:04', '2020-03-22 15:58:04'),
	(36, 'prius 1_27_jpg', 27, '2020-03-24 14:31:53', '2020-03-24 14:31:53'),
	(37, 'prius 2_27_jpg', 27, '2020-03-24 14:31:53', '2020-03-24 14:31:53'),
	(40, 'kdh_29_JPG', 29, '2020-04-05 08:16:22', '2020-04-05 08:16:22'),
	(41, 'kdh_i_29_JPG', 29, '2020-04-05 08:16:22', '2020-04-05 08:16:22');
/*!40000 ALTER TABLE `vehicle_pictures` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
